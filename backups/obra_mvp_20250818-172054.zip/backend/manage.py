#!/usr/bin/env python
import os, sys
os.makedirs('data', exist_ok=True)
def main():
    os.environ.setdefault('DJANGO_SETTINGS_MODULE','config.settings.dev')
    from django.core.management import execute_from_command_line
    execute_from_command_line(sys.argv)
if __name__ == '__main__':
    main()
